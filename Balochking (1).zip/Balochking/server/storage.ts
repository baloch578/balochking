import type { InsertLecture, Lecture } from "@shared/schema";

export interface IStorage {
  // Lectures
  createLecture(lecture: InsertLecture): Promise<Lecture>;
  getLectures(): Promise<Lecture[]>;
  getLectureById(id: string): Promise<Lecture | undefined>;
  getLecturesBySubject(subject: string): Promise<Lecture[]>;
  deleteLecture(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private lectures: Map<string, Lecture> = new Map();

  async createLecture(lecture: InsertLecture): Promise<Lecture> {
    const id = crypto.randomUUID();
    const newLecture: Lecture = {
      id,
      ...lecture,
    };
    this.lectures.set(id, newLecture);
    return newLecture;
  }

  async getLectures(): Promise<Lecture[]> {
    return Array.from(this.lectures.values());
  }

  async getLectureById(id: string): Promise<Lecture | undefined> {
    return this.lectures.get(id);
  }

  async getLecturesBySubject(subject: string): Promise<Lecture[]> {
    return Array.from(this.lectures.values()).filter(
      (lecture) => lecture.subject.toLowerCase() === subject.toLowerCase()
    );
  }

  async deleteLecture(id: string): Promise<void> {
    this.lectures.delete(id);
  }
}
