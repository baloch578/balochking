import type { Express } from "express";
import { z } from "zod";
import { insertLectureSchema } from "@shared/schema";
import type { IStorage } from "./storage";

export function registerRoutes(app: Express, storage: IStorage) {
  // Get all lectures
  app.get("/api/lectures", async (req, res) => {
    try {
      const lectures = await storage.getLectures();
      res.json(lectures);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch lectures" });
    }
  });

  // Get lectures by subject
  app.get("/api/lectures/subject/:subject", async (req, res) => {
    try {
      const { subject } = req.params;
      const lectures = await storage.getLecturesBySubject(subject);
      res.json(lectures);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch lectures" });
    }
  });

  // Get single lecture
  app.get("/api/lectures/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const lecture = await storage.getLectureById(id);
      
      if (!lecture) {
        return res.status(404).json({ error: "Lecture not found" });
      }
      
      res.json(lecture);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch lecture" });
    }
  });

  // Create lecture
  app.post("/api/lectures", async (req, res) => {
    try {
      const validatedData = insertLectureSchema.parse(req.body);
      const lecture = await storage.createLecture(validatedData);
      res.status(201).json(lecture);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create lecture" });
    }
  });

  // Delete lecture
  app.delete("/api/lectures/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteLecture(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete lecture" });
    }
  });

  // Visitor tracking endpoint
  app.post("/api/visitor", async (req, res) => {
    // Simple endpoint for tracking - can be expanded
    res.status(200).json({ success: true });
  });
}
