import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Lecture schema
export const lectures = pgTable("lectures", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  subject: text("subject").notNull(),
  topic: text("topic").notNull(),
  title: text("title").notNull(),
  date: text("date").notNull(),
  duration: text("duration").notNull(),
  videoUrl: text("video_url").notNull(),
});

export const insertLectureSchema = createInsertSchema(lectures).omit({
  id: true,
});

export type InsertLecture = z.infer<typeof insertLectureSchema>;
export type Lecture = typeof lectures.$inferSelect;

// Admin password schema
export const adminPasswords = pgTable("admin_passwords", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  password: text("password").notNull(),
});

export type AdminPassword = typeof adminPasswords.$inferSelect;
