import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import GlowingCard from "./GlowingCard";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Lecture } from "@shared/schema";

const subjects = [
  {
    id: "physics",
    name: "Physics",
    color: "physics" as const,
    description: "Ray Optics, Modern Physics, Mechanics",
  },
  {
    id: "chemistry",
    name: "Chemistry",
    color: "chemistry" as const,
    description: "Organic, Inorganic, Physical Chemistry",
  },
  {
    id: "botany",
    name: "Botany",
    color: "botany" as const,
    description: "Plant Anatomy, Physiology, Taxonomy",
  },
  {
    id: "zoology",
    name: "Zoology",
    color: "zoology" as const,
    description: "Animal Physiology, Genetics, Evolution",
  },
];

export default function SubjectsPage() {
  const [, setLocation] = useLocation();
  const [pressTimer, setPressTimer] = useState<NodeJS.Timeout | null>(null);
  const [pressProgress, setPressProgress] = useState(0);

  const { data: lectures = [] } = useQuery<Lecture[]>({
    queryKey: ["/api/lectures"],
  });

  const getLectureCount = (subjectId: string) => {
    return lectures.filter(l => l.subject.toLowerCase() === subjectId.toLowerCase()).length;
  };

  useEffect(() => {
    const verified = sessionStorage.getItem("telegram_verified");
    if (!verified) {
      setLocation("/telegram-verify");
    }
  }, [setLocation]);

  const handleAdminPress = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    let startTime = Date.now();
    
    const timer = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min((elapsed / 5000) * 100, 100);
      setPressProgress(progress);
      
      if (progress >= 100) {
        clearInterval(timer);
        setPressTimer(null);
        setPressProgress(0);
        setLocation("/admin-login");
      }
    }, 50);
    
    setPressTimer(timer);
  };

  const handleAdminRelease = () => {
    if (pressTimer) {
      clearInterval(pressTimer);
      setPressTimer(null);
      setPressProgress(0);
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-3">Subjects</h1>
          <p className="text-muted-foreground">Choose your subject to access lectures</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {subjects.map((subject) => (
            <GlowingCard key={subject.id} glowColor={subject.color}>
              <div className="p-6 space-y-4">
                <div className="flex items-start justify-between">
                  <h2 className="text-xl font-semibold text-foreground">{subject.name}</h2>
                  <Badge variant="secondary" data-testid={`badge-lecture-count-${subject.id}`}>
                    {getLectureCount(subject.id)} Lectures
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{subject.description}</p>
                <Button
                  onClick={() => setLocation(`/topics/${subject.id}`)}
                  className="w-full"
                  data-testid={`button-view-${subject.id}`}
                >
                  View Lectures
                </Button>
              </div>
            </GlowingCard>
          ))}
        </div>

        <div className="fixed bottom-6 right-6">
          <div className="relative">
            {pressProgress > 0 && (
              <div className="absolute -inset-2 bg-primary/20 rounded-full" 
                   style={{ opacity: pressProgress / 100 }} />
            )}
            <button
              onMouseDown={handleAdminPress}
              onMouseUp={handleAdminRelease}
              onMouseLeave={handleAdminRelease}
              onTouchStart={handleAdminPress}
              onTouchEnd={handleAdminRelease}
              className="text-muted-foreground/50 hover:text-muted-foreground transition-colors px-4 py-2"
              data-testid="button-admin"
            >
              Admin
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
