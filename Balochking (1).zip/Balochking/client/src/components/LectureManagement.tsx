import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Trash2, Play } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Lecture, InsertLecture } from "@shared/schema";

export default function LectureManagement() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    subject: "",
    topic: "",
    title: "",
    date: new Date().toISOString().split('T')[0],
    duration: "",
    videoUrl: "",
  });

  const { data: lectures = [] } = useQuery<Lecture[]>({
    queryKey: ["/api/lectures"],
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertLecture) => apiRequest("POST", "/api/lectures", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lectures"] });
      toast({
        title: "Success",
        description: "✅ Lecture successfully added!",
      });
      setFormData({
        subject: "",
        topic: "",
        title: "",
        date: new Date().toISOString().split('T')[0],
        duration: "",
        videoUrl: "",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/lectures/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lectures"] });
      toast({
        title: "Deleted",
        description: "Lecture removed successfully",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleDelete = (id: string) => {
    if (confirm("Delete this lecture?")) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => setLocation("/admin")}
          className="mb-6"
          data-testid="button-back"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Admin Panel
        </Button>

        <h1 className="text-3xl font-bold text-foreground mb-8">Lecture Processing</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-6">Add New Lecture</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Select
                  value={formData.subject}
                  onValueChange={(value) => setFormData({ ...formData, subject: value })}
                  required
                >
                  <SelectTrigger data-testid="select-subject">
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="physics">Physics</SelectItem>
                    <SelectItem value="chemistry">Chemistry</SelectItem>
                    <SelectItem value="botany">Botany</SelectItem>
                    <SelectItem value="zoology">Zoology</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="topic">Topic Name</Label>
                <Input
                  id="topic"
                  value={formData.topic}
                  onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                  placeholder="e.g., RAY OPTICS"
                  required
                  data-testid="input-topic"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="title">Lecture Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., RAY OPTICS - Lecture 01"
                  required
                  data-testid="input-title"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                  data-testid="input-date"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="duration">Duration</Label>
                <Input
                  id="duration"
                  value={formData.duration}
                  onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                  placeholder="e.g., 45:30"
                  required
                  data-testid="input-duration"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="videoUrl">Video URL</Label>
                <Input
                  id="videoUrl"
                  value={formData.videoUrl}
                  onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                  placeholder="YouTube, MP4, HLS (.m3u8), or any video link"
                  required
                  data-testid="input-video-url"
                />
              </div>

              <Button 
                type="submit" 
                className="w-full" 
                data-testid="button-add-lecture"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? "Adding..." : "Add Lecture"}
              </Button>
            </form>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-6">
              Current Lectures ({lectures.length})
            </h2>

            <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
              {lectures.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No lectures added yet</p>
                  <p className="text-sm mt-2">Add your first lecture using the form</p>
                </div>
              ) : (
                lectures.map((lecture) => (
                  <div
                    key={lecture.id}
                    className="p-4 bg-muted/30 rounded-md space-y-2"
                    data-testid={`lecture-item-${lecture.id}`}
                  >
                    <h4 className="font-medium text-foreground">{lecture.title}</h4>
                    <p className="text-sm text-muted-foreground">
                      <strong className="uppercase">{lecture.subject}</strong> • {lecture.topic} • {lecture.date} • {lecture.duration}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">URL: {lecture.videoUrl}</p>
                    <div className="flex gap-2 pt-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => setLocation(`/player/${lecture.id}`)}
                        data-testid={`button-play-${lecture.id}`}
                      >
                        <Play className="w-3 h-3 mr-1" />
                        Play
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDelete(lecture.id)}
                        data-testid={`button-delete-${lecture.id}`}
                      >
                        <Trash2 className="w-3 h-3 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
