import { useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import GlowingCard from "./GlowingCard";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Play } from "lucide-react";
import type { Lecture } from "@shared/schema";

const subjectColors = {
  physics: "physics" as const,
  chemistry: "chemistry" as const,
  botany: "botany" as const,
  zoology: "zoology" as const,
};

export default function TopicsPage() {
  const [match, params] = useRoute("/topics/:subject");
  const [, setLocation] = useLocation();
  const subject = params?.subject || "physics";
  
  const { data: allLectures = [], isLoading } = useQuery<Lecture[]>({
    queryKey: ["/api/lectures", "subject", subject],
    queryFn: () => fetch(`/api/lectures/subject/${subject}`).then(res => res.json()),
  });

  const topicGroups = allLectures.reduce((acc, lecture) => {
    if (!acc[lecture.topic]) acc[lecture.topic] = [];
    acc[lecture.topic].push(lecture);
    return acc;
  }, {} as Record<string, Lecture[]>);

  const subjectColor = subjectColors[subject as keyof typeof subjectColors];

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/subjects")}
            className="mb-4"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Subjects
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground capitalize">
            {subject} Lectures
          </h1>
        </div>

        <div className="space-y-6">
          {isLoading ? (
            <div className="text-center py-12 text-muted-foreground">Loading lectures...</div>
          ) : Object.keys(topicGroups).length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">No lectures available yet</div>
          ) : (
            Object.entries(topicGroups).map(([topic, topicLectures]) => (
              <GlowingCard key={topic} glowColor={subjectColor}>
                <div className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold text-foreground border-b border-border pb-3">
                    {topic}
                  </h2>
                  <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                    {topicLectures.map((lecture) => (
                      <div
                        key={lecture.id}
                        className="flex items-center justify-between p-4 bg-muted/30 rounded-md hover-elevate transition-all"
                        data-testid={`lecture-${lecture.id}`}
                      >
                        <div className="space-y-1">
                          <h3 className="font-medium text-foreground">{lecture.title}</h3>
                          <div className="flex gap-4 text-sm text-muted-foreground">
                            <span>{lecture.date}</span>
                            <span>{lecture.duration}</span>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => setLocation(`/player/${lecture.id}`)}
                          data-testid={`button-watch-${lecture.id}`}
                        >
                          <Play className="w-4 h-4 mr-1" />
                          Watch
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </GlowingCard>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
