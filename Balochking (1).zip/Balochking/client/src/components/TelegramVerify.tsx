import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ExternalLink } from "lucide-react";

export default function TelegramVerify() {
  const [, setLocation] = useLocation();
  const [hasJoined, setHasJoined] = useState(false);

  const handleJoinChannel = () => {
    window.open("https://t.me/+55jFTFG5Xno3NTZl", "_blank");
    setHasJoined(true);
  };

  const handleContinue = () => {
    sessionStorage.setItem("telegram_verified", "true");
    setLocation("/subjects");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <Card className="max-w-md w-full p-8 space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-foreground">Join Our Community</h2>
          <p className="text-muted-foreground">
            To access our lectures, please join our Telegram channel first
          </p>
        </div>

        <div className="h-px bg-gradient-to-r from-transparent via-telegram to-transparent" />

        <div className="space-y-4">
          <div className="text-center space-y-3">
            <h3 className="font-semibold text-foreground">Join Telegram Channel</h3>
            <p className="text-sm text-muted-foreground">
              Get latest updates, notes, and exclusive content on our Telegram channel
            </p>
          </div>

          <Button
            onClick={handleJoinChannel}
            className="w-full bg-telegram hover:bg-telegram/90"
            data-testid="button-join-telegram"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Join Telegram Channel
          </Button>

          <p className="text-xs text-center text-muted-foreground">
            After joining, click continue below
          </p>

          <Button
            onClick={handleContinue}
            disabled={!hasJoined}
            className="w-full"
            data-testid="button-continue"
          >
            I've Joined the Channel
          </Button>
        </div>
      </Card>
    </div>
  );
}
