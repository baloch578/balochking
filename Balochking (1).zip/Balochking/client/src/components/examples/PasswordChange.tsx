import PasswordChange from '../PasswordChange';

export default function PasswordChangeExample() {
  return <PasswordChange />;
}
