import TopicsPage from '../TopicsPage';

export default function TopicsPageExample() {
  return <TopicsPage />;
}
