import VideoPlayer from '../VideoPlayer';

export default function VideoPlayerExample() {
  return <VideoPlayer />;
}
