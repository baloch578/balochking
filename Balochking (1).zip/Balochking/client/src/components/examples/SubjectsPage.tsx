import SubjectsPage from '../SubjectsPage';

export default function SubjectsPageExample() {
  return <SubjectsPage />;
}
