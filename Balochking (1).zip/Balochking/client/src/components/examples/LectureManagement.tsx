import LectureManagement from '../LectureManagement';

export default function LectureManagementExample() {
  return <LectureManagement />;
}
