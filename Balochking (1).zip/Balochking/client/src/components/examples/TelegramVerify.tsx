import TelegramVerify from '../TelegramVerify';

export default function TelegramVerifyExample() {
  return <TelegramVerify />;
}
