import AdminPanel from '../AdminPanel';

export default function AdminPanelExample() {
  return <AdminPanel />;
}
