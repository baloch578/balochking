import GlowingCard from '../GlowingCard';

export default function GlowingCardExample() {
  return (
    <div className="bg-background p-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">
        <GlowingCard glowColor="physics">
          <div className="p-6">
            <h3 className="text-xl font-semibold text-foreground mb-2">Physics Glow</h3>
            <p className="text-muted-foreground">Electric blue 3D glowing effect</p>
          </div>
        </GlowingCard>
        
        <GlowingCard glowColor="chemistry">
          <div className="p-6">
            <h3 className="text-xl font-semibold text-foreground mb-2">Chemistry Glow</h3>
            <p className="text-muted-foreground">Magenta pink 3D glowing effect</p>
          </div>
        </GlowingCard>
        
        <GlowingCard glowColor="botany">
          <div className="p-6">
            <h3 className="text-xl font-semibold text-foreground mb-2">Botany Glow</h3>
            <p className="text-muted-foreground">Vivid green 3D glowing effect</p>
          </div>
        </GlowingCard>
        
        <GlowingCard glowColor="zoology">
          <div className="p-6">
            <h3 className="text-xl font-semibold text-foreground mb-2">Zoology Glow</h3>
            <p className="text-muted-foreground">Orange gold 3D glowing effect</p>
          </div>
        </GlowingCard>
      </div>
    </div>
  );
}
