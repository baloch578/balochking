import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, Upload, LogOut, Key, Users, Eye, TrendingUp } from "lucide-react";
import type { Lecture } from "@shared/schema";

export default function AdminPanel() {
  const [, setLocation] = useLocation();
  const [visitorCount] = useState(() => {
    const stored = localStorage.getItem("visitor_count");
    return stored ? parseInt(stored) : Math.floor(Math.random() * 500) + 100;
  });

  const { data: lectures = [] } = useQuery<Lecture[]>({
    queryKey: ["/api/lectures"],
  });

  useEffect(() => {
    const isLoggedIn = sessionStorage.getItem("admin_logged_in");
    if (!isLoggedIn) {
      setLocation("/subjects");
    }
  }, [setLocation]);

  const handleLogout = () => {
    sessionStorage.removeItem("admin_logged_in");
    setLocation("/subjects");
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-3">Admin Panel</h1>
          <p className="text-muted-foreground">Manage your content and settings</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Visitors</p>
                <h3 className="text-3xl font-bold text-foreground mt-1" data-testid="text-visitor-count">
                  {visitorCount.toLocaleString()}
                </h3>
              </div>
              <div className="p-3 bg-primary/10 rounded-full">
                <Eye className="w-6 h-6 text-primary" />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Lectures</p>
                <h3 className="text-3xl font-bold text-foreground mt-1" data-testid="text-lecture-count">
                  {lectures.length}
                </h3>
              </div>
              <div className="p-3 bg-physics/10 rounded-full">
                <Upload className="w-6 h-6 text-physics" />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Users</p>
                <h3 className="text-3xl font-bold text-foreground mt-1" data-testid="text-active-users">
                  {Math.floor(visitorCount * 0.15)}
                </h3>
              </div>
              <div className="p-3 bg-botany/10 rounded-full">
                <Users className="w-6 h-6 text-botany" />
              </div>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="p-6 space-y-4 hover-elevate transition-all">
            <div className="flex items-center gap-3">
              <Upload className="w-6 h-6 text-primary" />
              <h3 className="text-xl font-semibold text-foreground">Lecture Management</h3>
            </div>
            <p className="text-muted-foreground">Add, edit or remove lectures</p>
            <Button
              onClick={() => setLocation("/admin/lectures")}
              className="w-full"
              data-testid="button-manage-lectures"
            >
              Manage Lectures
            </Button>
          </Card>

          <Card className="p-6 space-y-4 hover-elevate transition-all">
            <div className="flex items-center gap-3">
              <Key className="w-6 h-6 text-primary" />
              <h3 className="text-xl font-semibold text-foreground">Password Change</h3>
            </div>
            <p className="text-muted-foreground">Update admin password</p>
            <Button
              onClick={() => setLocation("/admin/password")}
              className="w-full"
              data-testid="button-change-password"
            >
              Change Password
            </Button>
          </Card>

          <Card className="p-6 space-y-4 hover-elevate transition-all opacity-60">
            <div className="flex items-center gap-3">
              <Settings className="w-6 h-6 text-muted-foreground" />
              <h3 className="text-xl font-semibold text-foreground">User Management</h3>
            </div>
            <p className="text-muted-foreground">View user statistics</p>
            <Button disabled className="w-full">
              Coming Soon
            </Button>
          </Card>

          <Card className="p-6 space-y-4 hover-elevate transition-all opacity-60">
            <div className="flex items-center gap-3">
              <Settings className="w-6 h-6 text-muted-foreground" />
              <h3 className="text-xl font-semibold text-foreground">System Settings</h3>
            </div>
            <p className="text-muted-foreground">Configure website settings</p>
            <Button disabled className="w-full">
              Coming Soon
            </Button>
          </Card>
        </div>

        <div className="flex justify-center gap-4">
          <Button
            variant="secondary"
            onClick={() => setLocation("/subjects")}
            data-testid="button-back-website"
          >
            Back to Website
          </Button>
          <Button
            variant="destructive"
            onClick={handleLogout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
}
