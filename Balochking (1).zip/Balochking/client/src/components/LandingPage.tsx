import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function LandingPage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
      <div className="text-center space-y-6 max-w-4xl">
        <h1 className="text-5xl md:text-7xl font-black text-foreground tracking-tight leading-tight">
          BALOCH KING<br />LECTURE HUB 👑
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
          Access premium educational content and master Physics, Chemistry, Botany, and Zoology
        </p>
        <Button
          size="lg"
          className="mt-8 px-8 py-6 text-lg"
          onClick={() => setLocation("/telegram-verify")}
          data-testid="button-get-started"
        >
          Get Started
        </Button>
      </div>
    </div>
  );
}
