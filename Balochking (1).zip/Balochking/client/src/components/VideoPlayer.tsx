import { useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import type { Lecture } from "@shared/schema";

function getEmbedUrl(url: string): string {
  // YouTube
  if (url.includes('youtube.com/watch')) {
    const videoId = new URL(url).searchParams.get('v');
    return `https://www.youtube.com/embed/${videoId}`;
  }
  if (url.includes('youtu.be/')) {
    const videoId = url.split('youtu.be/')[1].split('?')[0];
    return `https://www.youtube.com/embed/${videoId}`;
  }
  
  // Vimeo
  if (url.includes('vimeo.com/')) {
    const videoId = url.split('vimeo.com/')[1].split('?')[0];
    return `https://player.vimeo.com/video/${videoId}`;
  }
  
  // Direct video files (MP4, etc.) or HLS
  if (url.match(/\.(mp4|m3u8|webm|ogg)$/i)) {
    return url;
  }
  
  // PHP or other encoded URLs - return as is
  return url;
}

export default function VideoPlayer() {
  const [match, params] = useRoute("/player/:id");
  const [, setLocation] = useLocation();
  const lectureId = params?.id || "";
  
  const { data: lecture, isLoading } = useQuery<Lecture>({
    queryKey: ["/api/lectures", lectureId],
    queryFn: () => fetch(`/api/lectures/${lectureId}`).then(res => res.json()),
    enabled: !!lectureId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!lecture) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">Video not found</h2>
          <Button onClick={() => setLocation("/subjects")} data-testid="button-back-home">
            Back to Home
          </Button>
        </div>
      </div>
    );
  }

  const embedUrl = getEmbedUrl(lecture.videoUrl);
  const isDirect = embedUrl.match(/\.(mp4|m3u8|webm|ogg)$/i);

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <Button
          variant="ghost"
          onClick={() => window.history.back()}
          data-testid="button-back"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="bg-black rounded-md overflow-hidden">
          <div className="aspect-video bg-black">
            {isDirect ? (
              <video
                src={embedUrl}
                className="w-full h-full"
                controls
                controlsList="nodownload"
                data-testid="video-player"
              />
            ) : (
              <iframe
                src={embedUrl}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                data-testid="video-iframe"
              />
            )}
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground" data-testid="text-video-title">
            {lecture.title}
          </h2>
        </div>
      </div>
    </div>
  );
}
