import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface GlowingCardProps {
  children: ReactNode;
  glowColor: "physics" | "chemistry" | "botany" | "zoology" | "multi";
  className?: string;
}

export default function GlowingCard({ children, glowColor, className }: GlowingCardProps) {
  const glowColors = {
    physics: "physics",
    chemistry: "chemistry",
    botany: "botany",
    zoology: "zoology",
    multi: "physics",
  };

  const borderGlowClass = {
    physics: "shadow-[0_0_15px_rgba(66,153,225,0.5),0_0_30px_rgba(66,153,225,0.3)] group-hover:shadow-[0_0_20px_rgba(66,153,225,0.7),0_0_40px_rgba(66,153,225,0.4)]",
    chemistry: "shadow-[0_0_15px_rgba(236,72,153,0.5),0_0_30px_rgba(236,72,153,0.3)] group-hover:shadow-[0_0_20px_rgba(236,72,153,0.7),0_0_40px_rgba(236,72,153,0.4)]",
    botany: "shadow-[0_0_15px_rgba(34,197,94,0.5),0_0_30px_rgba(34,197,94,0.3)] group-hover:shadow-[0_0_20px_rgba(34,197,94,0.7),0_0_40px_rgba(34,197,94,0.4)]",
    zoology: "shadow-[0_0_15px_rgba(251,146,60,0.5),0_0_30px_rgba(251,146,60,0.3)] group-hover:shadow-[0_0_20px_rgba(251,146,60,0.7),0_0_40px_rgba(251,146,60,0.4)]",
    multi: "shadow-[0_0_15px_rgba(66,153,225,0.5),0_0_30px_rgba(236,72,153,0.3)] group-hover:shadow-[0_0_20px_rgba(66,153,225,0.7),0_0_40px_rgba(236,72,153,0.4)]",
  };

  return (
    <div className={cn("relative group", className)}>
      <div className={cn("relative bg-card rounded-md border-2 transition-all duration-300", borderGlowClass[glowColor])}
           style={{
             borderColor: `hsl(var(--${glowColors[glowColor]}-glow))`,
           }}>
        {children}
      </div>
    </div>
  );
}
