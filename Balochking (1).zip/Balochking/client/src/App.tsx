import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import LandingPage from "@/components/LandingPage";
import TelegramVerify from "@/components/TelegramVerify";
import SubjectsPage from "@/components/SubjectsPage";
import TopicsPage from "@/components/TopicsPage";
import VideoPlayer from "@/components/VideoPlayer";
import AdminLogin from "@/components/AdminLogin";
import AdminPanel from "@/components/AdminPanel";
import LectureManagement from "@/components/LectureManagement";
import PasswordChange from "@/components/PasswordChange";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/telegram-verify" component={TelegramVerify} />
      <Route path="/subjects" component={SubjectsPage} />
      <Route path="/topics/:subject" component={TopicsPage} />
      <Route path="/player/:id" component={VideoPlayer} />
      <Route path="/admin-login" component={AdminLogin} />
      <Route path="/admin" component={AdminPanel} />
      <Route path="/admin/lectures" component={LectureManagement} />
      <Route path="/admin/password" component={PasswordChange} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
